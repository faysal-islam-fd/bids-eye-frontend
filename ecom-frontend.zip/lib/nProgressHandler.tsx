"use client"; // This is a Client Component

import { useEffect } from "react";
import NProgress from "nprogress";
import "nprogress/nprogress.css"; // Import default styles for the progress bar
import { usePathname } from "next/navigation"; // Use `usePathname` for detecting route changes

const NProgressHandler = () => {
  const pathname = usePathname(); // Get the current pathname

  useEffect(() => {
    // Start the progress bar when pathname changes
    NProgress.start();

    // Stop the progress bar when pathname has completed loading
    const handleRouteComplete = () => {
      NProgress.done();
    };

    // Set a timeout to handle slow transitions (for example, async operations)
    const timeoutId = setTimeout(() => {
      handleRouteComplete();
    }, 50);

    // Cleanup timeout and progress bar stop
    return () => {
      clearTimeout(timeoutId);
      NProgress.done();
    };
  }, [pathname]); // Effect runs when `pathname` changes (i.e., on route change)

  return null; // This component does not render anything
};

export default NProgressHandler;
