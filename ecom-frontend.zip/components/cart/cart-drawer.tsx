import {   useContext } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ShoppingBag, Trash2, ArrowRight } from "lucide-react";
import { useSelector } from "react-redux";
import {  RootState } from "@/types";
import { Config } from "@/config/Config";
import {
  ICartProduct,
  ICartProductItem,
  removeFromCart,
  setQuantity,
} from "@/redux/slice/cartSlice";
import { useDispatch } from "react-redux";
import Link from "next/link";
import { GetAuthContext } from "@/context/authContext";

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

const CartDrawer: React.FC<CartDrawerProps> = ({ isOpen, onClose }) => {
  const cartProducts = useSelector((state: RootState) => state.cart.products);
  const getProductPrice = (product: ICartProductItem) => {
    if (product.has_variations && product.first_combination) {
      return (
        product.first_combination.discount_price ??
        product.first_combination.price
      );
    }
    return product.discount_price ?? product.price;
  };
  const calculateSubTotal = (cartProducts: ICartProduct[]) => {
    return cartProducts.reduce((subTotal, item) => {
      const price = getProductPrice(item.product);
      const quantity = item.quantity || 1; // Default quantity is 1
      return subTotal + price * quantity;
    }, 0);
  };
  const subtotal = calculateSubTotal(cartProducts);
  const authContext = useContext(GetAuthContext);
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 bg-black z-40"
            onClick={onClose}
          />
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed right-0 top-0 h-full w-full max-w-md bg-white shadow-xl z-50 overflow-hidden flex flex-col"
          >
            <div className="p-4 border-b flex justify-between items-center">
              <h2 className="text-2xl font-semibold flex items-center">
                <ShoppingBag className="mr-2" /> Cart
              </h2>
              <button
                onClick={onClose}
                className="p-2 rounded-full hover:bg-gray-100 transition-colors"
                aria-label="Close cart"
              >
                <X />
              </button>
            </div>
            <div className="flex-grow overflow-y-auto py-4">
              <AnimatePresence>
                {cartProducts.map((item, index) => (
                  <CartItemArea key={index} item={item} />
                ))}
              </AnimatePresence>
            </div>
            <div className="p-4 border-t">
              <div className="flex justify-between items-center mb-4">
                <span className="font-semibold">Subtotal:</span>
                <span className="text-xl font-bold">
                  ৳ {subtotal.toFixed(2)}
                </span>
              </div>
              <div className="flex gap-2">
                <Link
                  onClick={onClose}
                  href={authContext?.user ? "/cart" : "/auth"}
                  className="w-full block text-[14px] uppercase text-stone-950 text-center bg-stone-200 py-3 rounded-md font-semibold hover:bg-stone-300 transition-colors"
                >
                  View Cart
                </Link>
                <Link
                  onClick={onClose}
                  href={authContext?.user ? "/checkout" : "/checkout-v2"}
                  className="group w-full flex gap-1 items-center justify-center text-[14px] uppercase text-center bg-stone-900 text-white py-3 rounded-md font-semibold hover:bg-stone-950 transition-colors"
                >
                  <span>Checkout</span>
                  <ArrowRight
                    size={18}
                    className="transform transition-transform duration-300 group-hover:translate-x-1"
                  />
                </Link>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default CartDrawer;

const CartItemArea = ({ item }: { item: ICartProduct }) => {
  const dispatch = useDispatch();
  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity >= 1) {
      if (item.product.has_variations) {
        if (Number(item.product.first_combination?.quantity) >= newQuantity) {
          dispatch(
            setQuantity({
              id: item.product.id,
              combination_id: item?.combination_id,
              quantity: newQuantity,
            })
          );
        }
      } else {
        if (Number(item.product.quantity) >= newQuantity) {
          dispatch(
            setQuantity({
              id: item.product.id,
              combination_id: item?.combination_id,
              quantity: newQuantity,
            })
          );
        }
      }

      // Here you would typically update the cart state/backend
    }
  };

  const remove = () => {
    if (item.product.has_variations) {
      dispatch(
        removeFromCart({ id: item.id, combination_id: item.combination_id })
      );
    } else {
      dispatch(removeFromCart({ id: item.id }));
    }
  };

  return (
    <>
      <motion.div
        key={item.id}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.3 }}
        className="flex items-center p-4 border-b"
      >
        <img
          src={Config.BACKEND_STORASE_URL + "/" + item.product.image}
          alt={item.product?.name}
          className="rounded-md h-[80px] w-[80px] object-cover mr-4"
        />
        <div className="flex-grow">
          <h3 className="font-semibold">{item.product.name}</h3>
          <div className="font-medium text-lg truncate flex gap-x-3">
            {item.product?.has_variations ? (
              <h3>
                {item.product.first_combination?.discount_price ??
                  item.product.first_combination?.price}
              </h3>
            ) : (
              <h3>{item.product?.discount_price ?? item.product?.price}</h3>
            )}
          </div>
          <div className="flex  gap-x-2 mt-2 items-center ">
            <div className="flex items-center ">
              <button
                onClick={() => handleQuantityChange(item?.quantity - 1)}
                className="px-2 py-1 border rounded-l-md hover:bg-gray-100"
              >
                -
              </button>
              <span className="px-4 py-1 border-t border-b">
                {item.quantity}
              </span>
              <button
                onClick={() => handleQuantityChange(item?.quantity + 1)}
                className="px-2 py-1 border rounded-r-md hover:bg-gray-100"
              >
                +
              </button>
            </div>

            {item.product.has_variations ? (
              <p className="text-sm text-gray-500 ">
                {/* {item.color} · Size {item.size} */}
                {item.product.first_combination?.sku}
              </p>
            ) : (
              ""
            )}
          </div>
        </div>
        <button
          onClick={remove}
          className="p-2 text-red-500 hover:bg-red-100 rounded-full transition-colors"
          aria-label={`Remove ${item.product.name} from cart`}
        >
          <Trash2 size={20} />
        </button>
      </motion.div>
    </>
  );
};
