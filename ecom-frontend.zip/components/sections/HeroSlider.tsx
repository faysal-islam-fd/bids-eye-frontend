"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { fadeIn } from "@/lib/animations";
import collectionApiSlice from "@/redux/api/collectionApiSlice";
import { ICollection } from "@/types";
import { Config } from "@/config/Config";
import Link from "next/link";

interface ISlides {
  image: string;
  title: string;
  subtitle: string;
  cta: string;
  slug: string;
}

const slideVariants = {
  initial: (direction: number) => ({
    x: direction > 0 ? 300 : -300,
    opacity: 0,
  }),
  animate: {
    x: 0,
    opacity: 1,
    transition: {
      x: { type: "spring", stiffness: 300, damping: 30 },
      opacity: { duration: 0.5 },
    },
  },
  exit: (direction: number) => ({
    x: direction > 0 ? -300 : 300,
    opacity: 0,
    transition: {
      x: { type: "spring", stiffness: 300, damping: 30 },
      opacity: { duration: 0.5 },
    },
  }),
};

export default function HeroSlider() {
  const [[currentSlide, direction], setSlide] = useState<[number, number]>([0, 0]);
  const [slides, setSlides] = useState<ISlides[]>([]);

  const nextSlide = () =>
    setSlide(([prevSlide]) => {
      const newSlide = slides.length > 0 ? (prevSlide + 1) % slides.length : prevSlide;
      return [newSlide, 1];
    });

  const prevSlide = () =>
    setSlide(([prevSlide]) => {
      const newSlide = slides.length > 0 ? (prevSlide - 1 + slides.length) % slides.length : prevSlide;
      return [newSlide, -1];
    });

  const { data, isSuccess } = collectionApiSlice.useGetAllCollectionsQuery("");

  useEffect(() => {
    if (slides.length > 0) {
      const interval = setInterval(() => {
        nextSlide();
      }, 5000); // Updated delay: 4.5 seconds
      return () => clearInterval(interval);
    }
  }, [slides]);

  useEffect(() => {
    if (isSuccess && data) {
      const slideData = data.map((collection: ICollection) => ({
        image: `${Config.BACKEND_STORASE_URL}/${collection.image}`,
        title: collection.name,
        subtitle: collection.description || "Discover the latest trends",
        cta: "Shop Now",
        slug: collection.slug,
      }));
      setSlides(slideData);
    }
  }, [isSuccess, data]);

  return (
    <div className="relative h-[400px] md:h-[600px] overflow-hidden">
      <AnimatePresence initial={false} custom={direction}>
        {slides.length > 0 && (
          <motion.div
            key={currentSlide}
            custom={direction}
            variants={slideVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            className="absolute inset-0 h-full lg:h-auto"
          >
            <div className="absolute inset-0 h-full w-full lg:h-auto">
              <img
                src={slides[currentSlide].image}
                alt={slides[currentSlide].title}
                
                className="object-cover h-full w-full lg:w-full lg:h-auto"
                loading={currentSlide === 0 ? "eager" : "lazy"}
     
              />
            </div>
            <div className="absolute inset-0 bg-black/40" />
            <div className="relative h-full flex items-center justify-center text-center text-white">
              <div className="max-w-4xl px-4">
                <motion.h1
                  variants={fadeIn("up", 0.2)}
                  initial="hidden"
                  animate="show"
                  className="text-xl md:text-4xl font-bold mb-2"
                >
                  {slides[currentSlide].title}
                </motion.h1>
                <motion.p
                  variants={fadeIn("up", 0.4)}
                  initial="hidden"
                  animate="show"
                  className="text-base md:text-lg mb-4 opacity-90"
                >
                  {slides[currentSlide].subtitle}
                </motion.p>
                <Link href={`/collections/${slides[currentSlide].slug}`}>
                  <motion.button
                    variants={fadeIn("up", 0.6)}
                    initial="hidden"
                    animate="show"
                    className="bg-white text-black px-4 py-2 text-sm rounded-md hover:bg-white/90 transition-colors"
                  >
                    {slides[currentSlide].cta}
                  </motion.button>
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/20 p-2 rounded-full hover:bg-white/30 transition-colors"
      >
        <ChevronLeft className="w-6 h-6 text-white" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/20 p-2 rounded-full hover:bg-white/30 transition-colors"
      >
        <ChevronRight className="w-6 h-6 text-white" />
      </button>
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setSlide([index, index > currentSlide ? 1 : -1])}
            className={`w-2 h-2 rounded-full transition-colors ${
              index === currentSlide ? "bg-white" : "bg-white/50"
            }`}
          />
        ))}
      </div>
    </div>
  );
}
