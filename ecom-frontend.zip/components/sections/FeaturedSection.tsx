

"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";

const features = [
  {
    icon: "🚚",
    title: "Free Shipping",
    description: "On orders over ৳ 5000"
  },
  {
    icon: "⚡",
    title: "Fast Delivery",
    description: "Within 24-48 hours in Dhaka"
  },
  {
    icon: "💯",
    title: "Quality Guarantee",
    description: "100% authentic products"
  }
];

export function FeaturedSection() {
  return (
    <div className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="p-6 text-center hover:shadow-lg transition-shadow">
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}