'use client';

import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Facebook, Twitter, Instagram, Youtube, CreditCard, Truck, Clock, Shield } from 'lucide-react';
import { fadeIn } from '@/lib/animations';
import categoryApiSlice from '@/redux/api/categoryApiSlice';
import { ICategory } from '@/types';
import { useEffect, useState } from 'react';
import Link from 'next/link';

export default function Footer() {
  const { data, isSuccess, isLoading,isError } =
    categoryApiSlice.useGetWithSubcategoriesQuery("");
 
    const [categories, setCategories] = useState<ICategory[]>([]);
    useEffect(() => {
      if (isSuccess) {
        if (data?.categories) {
          setCategories(data?.categories);
        }
      }
    }, [isSuccess, isError]);
  return (
    <footer className="bg-gray-900 text-gray-200">
      {/* Trust Badges */}
     

      {/* Main Footer */}
      <div className="container mx-auto py-12 px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About */}
          <motion.div
            variants={fadeIn('up', 0)}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
          >
            <h2 className="text-xl font-bold mb-4">About Us</h2>
            <p className="text-gray-400 mb-4">
            Birds Eye Fashion Retailer and Wholesaler in Bangladesh. We Have Many Item Like T-Shirt,POLO

            </p>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-primary" />
                <span className="text-sm">Shahbag Road, Dhaka, Bangladesh</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-5 h-5 text-primary" />
                <span className="text-sm">01770-586664
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-primary" />
                <span className="text-sm">birdseyeoffice22@gmail.com</span>
              </div>
            </div>
          </motion.div>

          {/* Categories */}
          <motion.div
            variants={fadeIn('up', 0.1)}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
          >
            <h2 className="text-xl font-bold mb-4">Categories</h2>
            <ul className="space-y-2">
                {categories.map((item) => {
                  
                  
                  return <li key={item.name}>
                    <Link
                  href={`/shop/${item.slug}`} className="text-gray-400 hover:text-primary transition-colors">
                  {item.name}
                  </Link>
                </li>
                  
                })}
            </ul>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            variants={fadeIn('up', 0.2)}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
          >
            <h2 className="text-xl font-bold mb-4">Quick Links</h2>
            <ul className="space-y-2">
             
              <li>
                  <Link href="/contact" className="text-gray-400 hover:text-primary transition-colors">
                      Contact Us
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-gray-400 hover:text-primary transition-colors">
                      Terms & Conditions
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-gray-400 hover:text-primary transition-colors">
                      Privacy Policy
                  </Link>
                </li>
            </ul>
          </motion.div>

          {/* Newsletter */}
          <motion.div
            variants={fadeIn('up', 0.3)}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
          >
            <h2 className="text-xl font-bold mb-4">Social Media</h2>
            
            <div className="flex gap-4 mt-6">
    
            <Link
                 
                  href="https://www.facebook.com/Birdseyefashionbd"
                  className="text-gray-400 hover:text-primary transition-colors"
                >
                 <Facebook className='hover:text-white' />
                </Link>
                <Link
                 
                  href="https://www.instagram.com/birdseyefashionbd"
                  className="text-gray-400 hover:text-primary transition-colors"
                >
                 <Instagram className='hover:text-white' />
                </Link>
                <Link
                 
                 href="https://x.com/birdseyefashio1"
                 className="text-gray-400 hover:text-primary transition-colors"
               >
                <Twitter  className='hover:text-white' />
               </Link>
               <Link
               href="https://www.youtube.com/@birdseyefashionhouse"
                className="text-gray-400 hover:text-primary transition-colors"
               >
                <Youtube className='hover:text-white' />
               </Link>
              </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800">
        <div className="container mx-auto py-6 px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-sm">
              © 2025 Birds Eye Fashion . All rights reserved.
            </p>
            {/* <div className="flex gap-4">
              <img src="/payment/visa.png" alt="Visa" className="h-8" />
              <img src="/payment/mastercard.png" alt="Mastercard" className="h-8" />
              <img src="/payment/paypal.png" alt="PayPal" className="h-8" />
              <img src="/payment/american-express.png" alt="American Express" className="h-8" />
            </div> */}
          </div>
        </div>
      </div>
    </footer>
  );
}