"use client";

import { useState, useEffect, useRef, useContext } from "react";
import { motion } from "framer-motion";
import { ShoppingBag, Search, Menu, X, User, ChevronUp } from "lucide-react";
import { fadeIn } from "@/lib/animations";
import CategoryMenu from "@/components/navigation/CategoryMenu";
import Link from "next/link";
import { useRouter } from "next/navigation";
import CartDrawer from "../cart/cart-drawer";
import useIsMobile from "@/hooks/use-is-mobile";
import categoryApiSlice from "@/redux/api/categoryApiSlice";
import { ICategory } from "@/types";
import { LogoutWrapper } from "@/lib/logout";
import { GetAuthContext } from "@/context/authContext";
import { CartContext } from "@/context/CartContext";

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCategoryOpen, setIsCategoryOpen] = useState(false);

  const [isProfilePopupOpen, setIsProfilePopupOpen] = useState(false);
  const authContext = useContext(GetAuthContext);
  const isMobile = useIsMobile();

  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const searchRef = useRef<HTMLDivElement>(null);
  const [searchValue, setSearchValue] = useState("");

  const profilePopupRef = useRef<HTMLDivElement>(null);

  const cartContext = useContext(CartContext);
  const isCartOpen = cartContext?.isCartOpen;
  const setIsCartOpen = cartContext?.setIsCartOpen;
  const toggleCart = cartContext?.toggleCart;
  useEffect(() => {
    if (isSearchOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isSearchOpen]);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  const toggleSearch = () => setIsSearchOpen(!isSearchOpen);
  const router = useRouter();
  const handleSearch = () => {
    if (searchValue) {
      router.push(`/search?q=${searchValue}`);
    }
  };

  const handleClickOutside = (event: MouseEvent) => {
    if (
      searchRef.current &&
      !searchRef.current.contains(event.target as Node)
    ) {
      setIsSearchOpen(false);
    }
  };

  useEffect(() => {
    if (isSearchOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isSearchOpen]);

  return (
    <>
      <header
        className={`sticky top-0   z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 ${
          isScrolled ? "shadow-sm" : ""
        }`}
      >
        <div className="container relative mx-auto py-4 px-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <motion.div
              variants={fadeIn("right")}
              initial="hidden"
              animate="show"
              className="flex items-center space-x-4"
            >
              <button
                className="lg:hidden"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </button>
              <Link href={"/"}>
                {" "}
                <img src="/logo-big.png" className="h-8 md:h-10" alt="Logo" />
              </Link>
            </motion.div>

            {/* Navigation */}
            <motion.nav
              variants={fadeIn("up")}
              initial="hidden"
              animate="show"
              className="hidden  lg:flex items-center space-x-10"
            >
              <Link href="/" className="hover:text-primary transition-colors">
                Home
              </Link>
              <Link
                href="/shop"
                className="hover:text-primary transition-colors"
              >
                Shop
              </Link>
              <div
                onMouseEnter={() => setIsCategoryOpen(true)}
                onMouseLeave={() => setIsCategoryOpen(false)}
                className=""
              >
                <button className="hover:text-primary transition-colors">
                  Categories
                </button>
                <CategoryMenu isOpen={isCategoryOpen} />
              </div>
              <Link
                href="/collections"
                className="hover:text-primary transition-colors"
              >
                Collections
              </Link>
              <Link
                href="/contact"
                className="hover:text-primary transition-colors"
              >
                Contact
              </Link>
            </motion.nav>

            {/* Icons */}
            <motion.div
              variants={fadeIn("left")}
              initial="hidden"
              animate="show"
              className="flex items-center space-x-4"
            >
              <div className="" ref={searchRef}>
                <Search
                  onClick={() => toggleSearch()}
                  className="w-5 h-5 cursor-pointer hover:text-primary transition-colors"
                />
                {isSearchOpen && (
                  <div className={`absolute left-0 w-full top-16`}>
                    <div
                      className={`px-4 mx-auto transform rounded-md w-[92%] p-2 bg-white shadow-lg ring-1 ring-black ring-opacity-5 transition-all duration-300 ease-in-out ${
                        isMobile ? "top-16" : "left-[20%]  top-12 sm:max-w-3xl"
                      }`}
                    >
                      <form
                        className={`flex items-center ${
                          isMobile ? "gap-2" : ""
                        }`}
                        onSubmit={(e) => {
                          e.preventDefault();
                          handleSearch();
                        }}
                      >
                        <input
                          value={searchValue}
                          onChange={(e) => setSearchValue(e.target.value)}
                          ref={searchInputRef}
                          type="text"
                          placeholder="Search products..."
                          className={`w-full rounded-md border-gray-300 px-4 py-2 focus:border-stone-800 focus:outline-none focus:ring-2 focus:ring-stone-800 ${
                            isMobile ? "text-sm flex-1" : ""
                          }`}
                        />
                        <button
                          type="submit"
                          className={`rounded-md bg-stone-700 p-2 text-white hover:bg-stone-800 focus:outline-none focus:ring-2 focus:ring-stone-800 focus:ring-offset-2 ${
                            isMobile ? "" : "ml-2"
                          }`}
                        >
                          <Search className="h-5 w-5" />
                        </button>
                      </form>
                    </div>
                  </div>
                )}
              </div>

              {/* <Heart className="w-5 h-5 cursor-pointer hover:text-primary transition-colors" /> */}
              <button
                onClick={toggleCart}
                className="relative text-gray-900 hover:text-gray-600"
                aria-label="Open cart"
              >
                <ShoppingBag className="h-5 w-5" />
                {/* <span className="absolute -right-2 -top-2 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-xs text-white">
                  0
                </span> */}
              </button>

              {authContext?.user ? (
                <div
                  onMouseEnter={() => setIsProfilePopupOpen(true)}
                  onMouseLeave={() => setIsProfilePopupOpen(false)}
                  className="hover:text-primary relative transition-colors"
                >
                  {!isMobile && <User className="cursor-pointer " />}
                  {isProfilePopupOpen && (
                    <div
                      ref={profilePopupRef}
                      className="absolute   -left-6    bg-white border border-gray-300 rounded-md shadow-lg z-50"
                    >
                      <ul>
                        <Link
                          href="/profile"
                          className=" px-6 py-2 hover:bg-gray-100 cursor-pointer"
                        >
                          Profile
                        </Link>
                        <li className=" px-6 py-2 hover:bg-gray-100 cursor-pointer">
                          <LogoutWrapper>Logout</LogoutWrapper>
                        </li>
                      </ul>
                    </div>
                  )}
                </div>
              ) : (
                <Link href={"/auth"}>
                  <User className="cursor-pointer " />
                </Link>
              )}
            </motion.div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <motion.nav
        variants={fadeIn("down")}
        initial="hidden"
        animate="show"
        exit="hidden"
        className={`fixed inset-0 bg-background/95 z-40 ${
          isMobileMenuOpen ? "block" : "hidden"
        }`}
      >
        <div className="container mx-auto flex flex-col items-start p-6 space-y-6">
          {/* Close Button */}
          <button
            className="self-end text-2xl"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <X />
          </button>

          {/* Menu Items */}
          <motion.div
            variants={fadeIn("right")}
            initial="hidden"
            animate="show"
            className="flex flex-col w-full space-y-6"
          >
            {/* Home Link */}
            <Link
              href="/"
              className="text-lg font-medium hover:text-primary transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Home
            </Link>

            {/* Shop Link */}
            <Link
              href="/shop"
              className="text-lg font-medium hover:text-primary transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Shop
            </Link>

            {/* Categories with Expandable Menu */}
            <div className="w-full">
              <button
                onClick={() => setIsCategoryOpen(!isCategoryOpen)}
                className="text-lg font-medium flex items-center justify-between w-full hover:text-primary transition-colors"
              >
                Categories
                <motion.span
                  className="ml-2"
                  animate={{ rotate: isCategoryOpen ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <ChevronUp size={18} />
                </motion.span>
              </button>

              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{
                  height: isCategoryOpen ? "auto" : 0,
                  opacity: isCategoryOpen ? 1 : 0,
                }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden mt-2 bg-white rounded-md shadow-md"
              >
                <CategoryMenuMobile setIsMobileMenuOpen={setIsMobileMenuOpen} />
              </motion.div>
            </div>

            {/* Collections Link */}
            <Link
              href="/collections"
              className="text-lg font-medium hover:text-primary transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Collections
            </Link>

            {/* Contact Link */}
            <Link
              href="/contact"
              className="text-lg font-medium hover:text-primary transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Contact
            </Link>

            {authContext?.user ? (
              <>
                <Link
                  href="/profile"
                  className="text-lg font-medium hover:text-primary transition-colors"
                >
                  Profile
                </Link>
                <LogoutWrapper>
                  <p className="text-lg text-start font-medium hover:text-primary transition-colors">
                    Logout
                  </p>
                </LogoutWrapper>
              </>
            ) : (
              <Link
                href="/auth"
                className="text-lg font-medium hover:text-primary transition-colors"
              >
                Login
              </Link>
            )}
          </motion.div>
        </div>
      </motion.nav>

      {isCartOpen !== undefined && setIsCartOpen !== undefined && (
        <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
      )}
    </>
  );
}

function setIsShopOpen(arg0: boolean) {
  throw new Error("Function not implemented.");
}

const CategoryMenuItem = ({
  item,
  setIsMobileMenuOpen,
}: {
  item: ICategory;
  setIsMobileMenuOpen: (value: boolean) => void;
}) => {
  const [isMenOpen, setIsMenOpen] = useState(false);
  return (
    <li>
      <button
        onClick={() => setIsMenOpen(!isMenOpen)}
        className="flex justify-between w-full hover:text-primary transition-colors"
      >
        <Link
          onClick={() => setIsMobileMenuOpen(false)}
          href={"/shop/" + item?.slug}
        >
          {item?.name}
        </Link>
        <motion.span
          className="ml-2"
          animate={{ rotate: isMenOpen ? 180 : 0 }}
          transition={{ duration: 0.3 }}
        >
          <ChevronUp size={18} />
        </motion.span>
      </button>
      {isMenOpen && (
        <motion.ul
          initial={{ height: 0, opacity: 0 }}
          animate={{
            height: "auto",
            opacity: 1,
          }}
          transition={{ duration: 0.5 }}
          className="ml-4 mt-2 space-y-2"
        >
          {item?.children &&
            item?.children.map((sub) => (
              <li onClick={() => setIsMobileMenuOpen(false)} key={sub.id}>
                <Link
                  onClick={() => setIsMobileMenuOpen(false)}
                  href={`/shop/${item?.slug}?sub_id=${sub.id}`}
                  className="hover:text-primary"
                >
                  {sub?.name}
                </Link>
              </li>
            ))}
        </motion.ul>
      )}
    </li>
  );
};

const CategoryMenuMobile = ({
  setIsMobileMenuOpen,
}: {
  setIsMobileMenuOpen: (value: boolean) => void;
}) => {
  const { data, isSuccess, isError } =
    categoryApiSlice.useGetWithSubcategoriesQuery("");

  const [categories, setCategories] = useState<ICategory[]>([]);
  useEffect(() => {
    if (isSuccess) {
      if (data?.categories) {
        setCategories(data?.categories);
      }
    }
  }, [isSuccess, isError]);
  return (
    <ul className="flex flex-col space-y-2 p-4">
      {categories.map((item) => (
        <CategoryMenuItem
          setIsMobileMenuOpen={setIsMobileMenuOpen}
          key={item.id}
          item={item}
        />
      ))}
    </ul>
  );
};
