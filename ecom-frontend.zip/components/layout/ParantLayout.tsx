"use client";
import ReduxProvider from "@/redux/app/ReduxProvider";
import React, { useContext } from "react";
import { Toaster } from "react-hot-toast";
import Header from "./Header";
import Footer from "./Footer";
import ContextProvider from "@/context/ContextProvider";
import { GetAuthContext } from "@/context/authContext";
const ParantLayout = ({ children }: { children: React.ReactNode }) => {
  const authContext = useContext(GetAuthContext);
  if (authContext?.isLoading) {
    return "Loading";
  } else {
    return (
      <div>
        <Toaster />
        <ReduxProvider>
          <ContextProvider>
            <Header />
            {children}
            <Footer />
          </ContextProvider>
        </ReduxProvider>
      </div>
    );
  }
};

export default ParantLayout;
