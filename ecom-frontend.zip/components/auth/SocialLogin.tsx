import React from "react";
import { Button } from "../ui/button";
import { Config } from "@/config/Config";

const SocialLogin = () => {
  const handleSocailLogin = () => {
    location.replace(`${Config.BACKEND_BASE_URL}/auth/google`);
  };

  //ahonkhan.vercel.app/auth/process

  https: return (
    <div>
      <div className="grid grid-cols-1 gap-4">
        <Button onClick={handleSocailLogin} variant="outline" type="button">
          <img
            src="https://www.svgrepo.com/show/475656/google-color.svg"
            alt="Google"
            className="h-5 w-5 mr-2"
          />
          Google
        </Button>
      </div>
    </div>
  );
};

export default SocialLogin;
