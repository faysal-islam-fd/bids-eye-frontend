"use client";

import { motion, AnimatePresence } from "framer-motion";
import { fadeIn } from "@/lib/animations";
import categoryApiSlice from "@/redux/api/categoryApiSlice";
import { useEffect, useState } from "react";
import { ICategory } from "@/types";
import Link from "next/link";

interface CategoryMenuProps {
  isOpen: boolean;
}


export default function CategoryMenu({ isOpen }: CategoryMenuProps) {
  const { data, isLoading, isSuccess, isError } =
    categoryApiSlice.useGetWithSubcategoriesQuery("");

  const [categories, setCategories] = useState<ICategory[]>([]);
  useEffect(() => {
    if (isSuccess) {
      if (data?.categories) {
        setCategories(data?.categories);
      }
    }
  }, [isSuccess, isError]);
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 z-40"
          />

          {/* Mega Menu */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-full  right-[15%]  -translate-x-1/2 w-[850px] mx-auto bg-white rounded-b-lg shadow-xl z-50"
          >
            <div className="grid grid-cols-4 p-8">
              {categories.map((category, index) => (
                <motion.div
                  key={category.id}
                  variants={fadeIn("up", index * 0.1)}
                  initial="hidden"
                  animate="show"
                  className="space-y-4"
                >
                  <Link
                    href={"/shop/" + category.slug}
                    className="font-bold text-lg border-b pb-2"
                  >
                    {category.name}
                  </Link>
                  <ul className="space-y-2">
                    {category.children.map((item) => (
                      <li key={item.id}>
                        <Link
                          href={"/shop/" + category.slug + "?sub_id=" + item.id}
                          className="text-gray-600 hover:text-primary transition-colors text-sm block py-1"
                        >
                          {item.name}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
