"use client";

import { motion } from "framer-motion";
import { ProductCardBase } from "./ProductCard";
import { useParams } from "next/navigation";
import productApiSlice from "@/redux/api/productsApiSlice";
import { useEffect, useState } from "react";
import { IProduct } from "@/types";

export default function RelatedProducts() {
  const { slug } = useParams();
  const [page, setPage] = useState(1);
  const { data, isSuccess, refetch } =
    productApiSlice.useGetRelatedProductsQuery(
      { slug: slug, page: 1 },
      { skip: !slug }
    );
  const [products, setProducts] = useState<IProduct[]>([]);

  useEffect(() => {
    if (isSuccess) {
      if (data?.products) {
        setProducts(data?.products);
      }
    }
  }, [isSuccess, data]);
  return (
    <section className="py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
      >
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-xl md:text-2xl  font-bold">Related Products</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6 lg:gap-8">
          {products.map((product, index) => (
            <ProductCardBase key={product.id} product={product} index={index} />
          ))}
        </div>
      </motion.div>

      <motion.button
        onClick={() => {
          setPage(page + 1);
          refetch();
        }}
        whileTap={{ scale: 0.95 }}
        className="text-primary mt-5 flex w-full justify-center hover:underline font-medium"
      >
        Load more
      </motion.button>
    </section>
  );
}
