"use client";

import { motion } from "framer-motion";
import { useState } from "react";
import { IProductImage } from "@/types";
import { Config } from "@/config/Config";

export default function ProductGallery({
  product_images,
}: {
  product_images: IProductImage[];
}) {
  const [selectedImage, setSelectedImage] = useState(0);

  return (
    <div className="grid gap-4">
      {/* Main Product Image */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative aspect-square overflow-hidden rounded-xl bg-gray-100"
      >
        <img
        src={`${Config.BACKEND_STORASE_URL}/${product_images[selectedImage]?.image}`}
          alt="Product image"
          
          className="object-cover transition-all hover:scale-110 cursor-pointer"
          loading="eager"
          

        />
      </motion.div>

      {/* Thumbnail Images */}
      <div className="grid grid-cols-4 gap-4">
        {product_images.map((image, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className={`relative aspect-square cursor-pointer rounded-lg overflow-hidden ${
              selectedImage === index ? "ring-2 ring-black dark:ring-white" : ""
            }`}
            onClick={() => setSelectedImage(index)}
          >
            <img
            src={`${Config.BACKEND_STORASE_URL}/${image.image}`}
              alt={`Product thumbnail ${index + 1}`}
              className="object-cover transition-transform duration-300 hover:scale-110"
              loading="lazy"
            />
          </motion.div>
        ))}
      </div>
    </div>
  );
}
