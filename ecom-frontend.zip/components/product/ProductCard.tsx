"use client";

import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { IProduct } from "@/types";
import { fadeIn } from "@/lib/animations";
import { Config } from "@/config/Config";
import Link from "next/link";

export const ProductCardBase = ({
  product,
  index,
}: {
  product: IProduct;
  index: number;
}) => {
  return (
    <motion.div
      key={product.id}
      variants={fadeIn("up", index * 0.1)}
      className="overflow-hidden border h-fit border-stone-300 shadow-md rounded-md"
    >
      <div className="relative group h-fit cursor-pointer overflow-hidden aspect-square">
        <Link href={`/product/${product.slug}`}>
          <img
          
            src={`${Config.BACKEND_STORASE_URL}/${product.image}`}
            alt={product.name}
            className=" group-hover:scale-110 transition-all duration-200 object-cover"
          />
        </Link>
      </div>
      <div className="p-4">
        <p className="text-sm text-muted-foreground mb-1">
          {product.category?.name}
        </p>
        <h3 className="uppercase text-[16px] mb-2">{product.name}</h3>
        {product?.has_variations ? (
          <p className="text-primary font-semibold">
            ৳ {product.first_combination && product.first_combination.price}
          </p>
        ) : (
          <p className="text-primary font-semibold">৳ {product.price}</p>
        )}

        <button className="text-[13px] group mt-2">
          <Link
            className="flex bg-stone-900 rounded-md text-white px-6 py-2 items-center gap-1"
            href={`/product/${product.slug}`}
          >
            <span>Buy Now</span>
            <ArrowRight
              size={15}
              className="group-hover:translate-x-1 transition-all duration-200 cursor-pointer"
            />
          </Link>
        </button>
      </div>
    </motion.div>
  );
};
