import { Config } from "@/config/Config";
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
const collectionApiSlice = createApi({
  reducerPath: "api/collections",
  baseQuery: fetchBaseQuery({
    baseUrl: `${Config.BACKEND_API_URL}/collections`,
    prepareHeaders: (headers) => {
      headers.set("Content-Type", "application/json");
      headers.set(
        "Authorization",
        `Bearer ${localStorage.getItem("accessToken")}`
      );
      return headers;
    },
  }),
  endpoints: (builder) => ({
    getAllCollections: builder.query({
      query: () => "",
    }),
    getProductsByCollectionSlug: builder.query({
      query: (slug) => "/get-products-by-collection/" + slug,
    }),
    getAllCollectionsWithProducts: builder.query({
      query: () => "/view-with-products",
    }),
  }),
});

export default collectionApiSlice;
