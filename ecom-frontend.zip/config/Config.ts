export class Config {
  static BACKEND_API_URL = "https://api.birdseyefashion.com/api";
  static BACKEND_BASE_URL = "https://api.birdseyefashion.com";
  static BACKEND_STORASE_URL =
    "https://api.birdseyefashion.com/storage/app/public";
}
