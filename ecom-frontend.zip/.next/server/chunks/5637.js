"use strict";exports.id=5637,exports.ids=[5637],exports.modules={5705:(e,t,a)=>{a.d(t,{Z:()=>l});var r=a(75593);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=(0,r.Z)("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]])},43618:(e,t,a)=>{a.d(t,{f:()=>d});var r=a(9885),l=a(43979),o=a(60080),s=r.forwardRef((e,t)=>(0,o.jsx)(l.WV.label,{...e,ref:t,onMouseDown:t=>{let a=t.target;a.closest("button, input, select, textarea")||(e.onMouseDown?.(t),!t.defaultPrevented&&t.detail>1&&t.preventDefault())}}));s.displayName="Label";var d=s}};