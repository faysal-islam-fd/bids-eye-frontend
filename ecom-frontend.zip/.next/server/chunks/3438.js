"use strict";exports.id=3438,exports.ids=[3438],exports.modules={1264:(e,t,a)=>{a.d(t,{Z:()=>d});var r=a(75593);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let d=(0,r.Z)("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]])},85574:(e,t,a)=>{a.d(t,{Z:()=>d});var r=a(75593);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let d=(0,r.Z)("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]])},44155:(e,t,a)=>{a.d(t,{Z:()=>d});var r=a(75593);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let d=(0,r.Z)("Printer",[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]])},43618:(e,t,a)=>{a.d(t,{f:()=>n});var r=a(9885),d=a(43979),l=a(60080),o=r.forwardRef((e,t)=>(0,l.jsx)(d.WV.label,{...e,ref:t,onMouseDown:t=>{let a=t.target;a.closest("button, input, select, textarea")||(e.onMouseDown?.(t),!t.defaultPrevented&&t.detail>1&&t.preventDefault())}}));o.displayName="Label";var n=o}};