(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[648],{5531:function(e,t,r){"use strict";r.d(t,{Z:function(){return u}});var o=r(2265);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),s=(...e)=>e.filter((e,t,r)=>!!e&&r.indexOf(e)===t).join(" ");/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var i={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,o.forwardRef)(({color:e="currentColor",size:t=24,strokeWidth:r=2,absoluteStrokeWidth:n,className:a="",children:u,iconNode:l,...c},d)=>(0,o.createElement)("svg",{ref:d,...i,width:t,height:t,stroke:e,strokeWidth:n?24*Number(r)/Number(t):r,className:s("lucide",a),...c},[...l.map(([e,t])=>(0,o.createElement)(e,t)),...Array.isArray(u)?u:[u]])),u=(e,t)=>{let r=(0,o.forwardRef)(({className:r,...i},u)=>(0,o.createElement)(a,{ref:u,iconNode:t,className:s(`lucide-${n(e)}`,r),...i}));return r.displayName=`${e}`,r}},3715:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});var o=r(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,o.Z)("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]])},2508:function(e,t,r){Promise.resolve().then(r.bind(r,1523))},1523:function(e,t,r){"use strict";r.r(t);var o=r(7437),n=r(1289),s=r(3715),i=r(2265);t.default=e=>{let{children:t}=e,r=(0,i.useContext)(n.a);return(null==r?void 0:r.isLoading)?(0,o.jsx)("div",{className:"h-screen w-screen flex items-center justify-center",children:(0,o.jsx)(s.Z,{className:"w-20 h-20 animate-spin"})}):(null==r?void 0:r.user)!==null?(0,o.jsx)("div",{children:t}):void location.replace("/auth")}},8702:function(e,t,r){"use strict";r.d(t,{D:function(){return o}});class o{}o.BACKEND_API_URL="https://api.birdseyefashion.com/api",o.BACKEND_BASE_URL="https://api.birdseyefashion.com",o.BACKEND_STORASE_URL="https://api.birdseyefashion.com/storage/app/public"},1289:function(e,t,r){"use strict";r.d(t,{V:function(){return a},a:function(){return i}});var o=r(7437),n=r(6074),s=r(2265);let i=(0,s.createContext)(void 0),a=e=>{let{children:t}=e,[r,a]=(0,s.useState)(null),[u,l]=(0,s.useState)(!0),{data:c,isSuccess:d,isError:p,error:f}=n.Z.useGetAuthInfoQuery("");return(0,s.useEffect)(()=>{d&&(a(c),l(!1)),p&&l(!1)},[d,p,c]),(0,o.jsx)(i.Provider,{value:{user:r,setUser:a,isLoading:u,setIsLoading:l,updateUser:e=>{a(t=>({...t,user:{...e}}))}},children:t})}},6074:function(e,t,r){"use strict";var o=r(8702),n=r(5687),s=r(329);let i=(0,n.LC)({reducerPath:"api/auth",baseQuery:(0,s.ni)({baseUrl:"".concat(o.D.BACKEND_API_URL,"/auth"),prepareHeaders:e=>(e.set("Content-Type","application/json"),e.set("Authorization","Bearer ".concat(localStorage.getItem("accessToken"))),e)}),endpoints:e=>({sendSignupOtp:e.mutation({query:e=>({url:"/signup-otp",method:"post",body:{email:e}})}),signup:e.mutation({query:e=>{let{email:t,password:r,varificationCode:o,firstName:n,passwordConfirmation:s,phone:i}=e;return{url:"/signup",method:"post",body:{firstName:n,email:t,verificationCode:o,password:r,password_confirmation:s,phone:i}}}}),login:e.mutation({query:e=>{let{email:t,password:r}=e;return{url:"/login",method:"post",body:{email:t,password:r}}}}),sendResetPasswordLink:e.mutation({query:e=>{let{email:t,frontendURL:r}=e;return{url:"/reset-password-mail",method:"post",body:{email:t,frontendURL:r}}}}),resetPassword:e.mutation({query:e=>{let{password_reset_token:t,email:r,password:o,password_confirmation:n}=e;return{url:"/reset-password",method:"post",body:{password_reset_token:t,email:r,password:o,password_confirmation:n}}}}),getAuthInfo:e.query({query:()=>"/info"}),logout:e.mutation({query:()=>({url:"/logout",method:"post"})})})});t.Z=i},622:function(e,t,r){"use strict";/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var o=r(2265),n=Symbol.for("react.element"),s=Symbol.for("react.fragment"),i=Object.prototype.hasOwnProperty,a=o.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,u={key:!0,ref:!0,__self:!0,__source:!0};function l(e,t,r){var o,s={},l=null,c=null;for(o in void 0!==r&&(l=""+r),void 0!==t.key&&(l=""+t.key),void 0!==t.ref&&(c=t.ref),t)i.call(t,o)&&!u.hasOwnProperty(o)&&(s[o]=t[o]);if(e&&e.defaultProps)for(o in t=e.defaultProps)void 0===s[o]&&(s[o]=t[o]);return{$$typeof:n,type:e,key:l,ref:c,props:s,_owner:a.current}}t.Fragment=s,t.jsx=l,t.jsxs=l},7437:function(e,t,r){"use strict";e.exports=r(622)}},function(e){e.O(0,[723,687,971,864,744],function(){return e(e.s=2508)}),_N_E=e.O()}]);