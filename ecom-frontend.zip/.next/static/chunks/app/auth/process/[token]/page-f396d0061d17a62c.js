(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[348],{5531:function(e,r,t){"use strict";t.d(r,{Z:function(){return c}});var n=t(2265);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),s=(...e)=>e.filter((e,r,t)=>!!e&&t.indexOf(e)===r).join(" ");/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var a={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,n.forwardRef)(({color:e="currentColor",size:r=24,strokeWidth:t=2,absoluteStrokeWidth:o,className:i="",children:c,iconNode:l,...u},f)=>(0,n.createElement)("svg",{ref:f,...a,width:r,height:r,stroke:e,strokeWidth:o?24*Number(t)/Number(r):t,className:s("lucide",i),...u},[...l.map(([e,r])=>(0,n.createElement)(e,r)),...Array.isArray(c)?c:[c]])),c=(e,r)=>{let t=(0,n.forwardRef)(({className:t,...a},c)=>(0,n.createElement)(i,{ref:c,iconNode:r,className:s(`lucide-${o(e)}`,t),...a}));return t.displayName=`${e}`,t}},3715:function(e,r,t){"use strict";t.d(r,{Z:function(){return o}});var n=t(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,n.Z)("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]])},1004:function(e,r,t){Promise.resolve().then(t.bind(t,8157))},8157:function(e,r,t){"use strict";t.r(r);var n=t(7437),o=t(3715),s=t(4033),a=t(2265);r.default=()=>{let{token:e}=(0,s.useParams)(),r=decodeURIComponent(e);return(0,a.useEffect)(()=>{"undefined"!=typeof localStorage&&e&&(localStorage.setItem("accessToken",r),location.replace("/"))},[]),(0,n.jsx)("div",{children:(0,n.jsx)("div",{className:"flex justify-center items-center h-[600px]",children:(0,n.jsx)(o.Z,{className:"mr-2 h-20 w-20 animate-spin"})})})}},622:function(e,r,t){"use strict";/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var n=t(2265),o=Symbol.for("react.element"),s=Symbol.for("react.fragment"),a=Object.prototype.hasOwnProperty,i=n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,c={key:!0,ref:!0,__self:!0,__source:!0};function l(e,r,t){var n,s={},l=null,u=null;for(n in void 0!==t&&(l=""+t),void 0!==r.key&&(l=""+r.key),void 0!==r.ref&&(u=r.ref),r)a.call(r,n)&&!c.hasOwnProperty(n)&&(s[n]=r[n]);if(e&&e.defaultProps)for(n in r=e.defaultProps)void 0===s[n]&&(s[n]=r[n]);return{$$typeof:o,type:e,key:l,ref:u,props:s,_owner:i.current}}r.Fragment=s,r.jsx=l,r.jsxs=l},7437:function(e,r,t){"use strict";e.exports=t(622)},4033:function(e,r,t){e.exports=t(290)}},function(e){e.O(0,[971,864,744],function(){return e(e.s=1004)}),_N_E=e.O()}]);