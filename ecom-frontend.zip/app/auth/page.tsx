"use client";

import { motion } from "framer-motion";
import { useState } from "react";
import { LogIn, UserPlus, ShoppingBag } from "lucide-react";
import LoginForm from "@/components/auth/login-form";
import SignupForm from "@/components/auth/signup-form";
import Image from "next/image";

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-4xl bg-white rounded-2xl shadow-xl overflow-hidden"
      >
        <div className="flex flex-col md:flex-row">
          {/* Left Side - Hero Section */}
          <div className="md:w-1/2 bg-primary p-12 text-white flex flex-col justify-center items-center">
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2 }}
              className="text-center"
            >
             <div className="">
             <Image alt="Logo" width={200} className="mx-auto mb-2" height={200} src="/logo.png" />
             </div>
              <h1 className="text-3xl font-bold mb-4">Welcome to <br />Birds Eye Fashion</h1>
              <p className="text-gray-100 mb-8">
                Your one-stop destination for premium shopping experience
              </p>
            </motion.div>
          </div>

          {/* Right Side - Form Section */}
          <div className="md:w-1/2 p-12">
            <div className="flex justify-center mb-8">
              <div className="inline-flex rounded-lg border border-gray-200 p-1">
                <button
                  onClick={() => setIsLogin(true)}
                  className={`flex items-center px-4 py-2 rounded-md transition-all ${
                    isLogin
                      ? "bg-primary text-white"
                      : "text-gray-500 hover:text-primary"
                  }`}
                >
                  <LogIn className="w-4 h-4 mr-2" />
                  Login
                </button>
                <button
                  onClick={() => setIsLogin(false)}
                  className={`flex items-center px-4 py-2 rounded-md transition-all ${
                    !isLogin
                      ? "bg-primary text-white"
                      : "text-gray-500 hover:text-primary"
                  }`}
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  Sign Up
                </button>
              </div>
            </div>

            <motion.div
              key={isLogin ? "login" : "signup"}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              {isLogin ? <LoginForm /> : <SignupForm />}
            </motion.div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
