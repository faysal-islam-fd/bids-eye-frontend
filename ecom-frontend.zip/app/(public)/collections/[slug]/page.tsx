"use client";

import { motion } from "framer-motion";
import { ShopFilters } from "@/components/shop/shop-filters";
import { useParams, useSearchParams } from "next/navigation";
import productApiSlice from "@/redux/api/productsApiSlice";
import { useEffect, useState, useRef } from "react";
import { ICategory, IProduct } from "@/types";
import { ProductCardBase } from "@/components/product/ProductCard";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import collectionApiSlice from "@/redux/api/collectionApiSlice";

export default function CategoryPage() {
  const { slug } = useParams();
  const [products, setProducts] = useState<IProduct[]>([]);

  const { data, isSuccess } =
    collectionApiSlice.useGetProductsByCollectionSlugQuery(slug, {
      skip: !slug,
    });

  useEffect(() => {
    if (isSuccess) {
      if (data?.products) {
        setProducts(data?.products);
      }
    }
  }, [data, isSuccess]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen bg-background"
    >
      <div className="container mx-auto px-4 py-8">
        <div className="">
          <motion.div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products.map((product, index) => (
              <motion.div key={product.id}>
                <ProductCardBase product={product} index={index} />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}
