"use client";

import { motion } from "framer-motion";
import { ShirtsSection } from "@/components/shop/sections/shirt-section";
import { TshirtsSection } from "@/components/shop/sections/tshirt-section";
import { HoodiesSection } from "@/components/shop/sections/hooide-section";
import { PantsSection } from "@/components/shop/sections/pants-section";
import productApiSlice from "@/redux/api/productsApiSlice";
import { useEffect, useState } from "react";
import { ICategory } from "@/types";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ProductCardBase } from "@/components/product/ProductCard";
import { encode } from "@/lib/utils";
import { Encoder } from "@/lib/Encoder";

export default function ShopPage() {
  const { data, isSuccess } =
    productApiSlice.useGetAllProductsGroupByCategoriesQuery("");

  const [categories, setCategories] = useState<ICategory[]>([]);
  useEffect(() => {
    if (data?.categories) {
      setCategories(data?.categories);
    }
  }, [data, isSuccess]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="min-h-screen bg-background"
    >
      <div className="container mx-auto px-4 py-8">
        {categories?.map((item, index) =>
          item?.products && item?.products.length > 0 ? (
            <CategorySection key={index} category={item} />
          ) : (
            ""
          )
        )}
      </div>
    </motion.div>
  );
}

const CategorySection = ({ category }: { category: ICategory }) => {
  return (
    <section className="mb-16">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-bold">{category?.name}</h2>
        <Link href={`/shop/${category?.slug}`}>
          <Button variant="ghost" className="group">
            View All
            <ArrowRight className="ml-2 h-4 w-4 transform group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </div>

      {!category?.products && (
        <>
          <div className="">No products available</div>
        </>
      )}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {category?.products && category?.products?.length > 0
          ? category?.products?.map((product, index) => (
              <ProductCardBase key={index} index={index} product={product} />
            ))
          : ""}
      </div>
    </section>
  );
};
