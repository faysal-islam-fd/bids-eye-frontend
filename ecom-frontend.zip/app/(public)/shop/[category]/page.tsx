"use client";

import { motion } from "framer-motion";
import { ShopFilters } from "@/components/shop/shop-filters";
import { useParams, useSearchParams } from "next/navigation";
import productApiSlice from "@/redux/api/productsApiSlice";
import { useEffect, useState, useRef } from "react";
import { ICategory, IProduct } from "@/types";
import { ProductCardBase } from "@/components/product/ProductCard";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { ProductCardSkeleton } from "@/components/skeleton/ProductSkeleton";

export default function CategoryPage() {
  const { category } = useParams();
  const [page, setPage] = useState(1);
  const [categoryData, setCategoryData] = useState<ICategory>();
      const [subCategoryData, setSubCategoryData] = useState<ICategory>();
  const [products, setProducts] = useState<IProduct[]>([]);
  const searchParam = useSearchParams();
  const { data, isSuccess, isLoading } =
    productApiSlice.useGetBySingleCategoryQuery(
      {
        id: category,
        limit: 4,
        page: page,
        sub_id: searchParam.get("sub_id") ?? null,
      },
      {
        skip: !category,
      }
    );

  useEffect(() => {
    setProducts([]);
  }, [searchParam.get("sub_id")]);

  useEffect(() => {
    if (isSuccess && data?.category) {
      if (page === 1) {
        setCategoryData(data?.category);
      }
    
    if(data?.children){
    		setSubCategoryData(data?.children);
    }

      const newData = products.concat(data?.category?.products);
      setProducts(newData);
    }
  }, [data]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen bg-background"
    >
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">       
          {subCategoryData?subCategoryData?.name:categoryData?.name}
        </h1>
        <div className="">
          {page === 1 ? (
            <>
              {isSuccess && (
                <motion.div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {products.map((product, index) => (
                    <motion.div key={product.id}>
                      <ProductCardBase product={product} index={index} />
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </>
          ) : (
            <motion.div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {products.map((product, index) => (
                <motion.div key={product.id}>
                  <ProductCardBase product={product} index={index} />
                </motion.div>
              ))}
            </motion.div>
          )}
     
          <div className="flex justify-center items-center">
            {isLoading && (
                 <div 
                 className="grid w-full grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5"
                 >
                   {Array.from({ length: 8 }).map((_, index) => (
                    <ProductCardSkeleton key={index} />
                  ))}
        
                 </div>
            )}
          </div>
      
           {!isLoading && isSuccess && products.length === 0 && (
            <>
              <div className="flex justify-center ">
                <h1 className="text-3xl font-bold mb-8">
           
                </h1>
              </div>
            </>
          )}
      
          {products.length > 0 && (
            <div className="flex justify-center mt-8">
              <Button onClick={() => setPage(page + 1)}>Load more</Button>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
