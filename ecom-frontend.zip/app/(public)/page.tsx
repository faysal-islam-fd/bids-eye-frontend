"use client";

import { motion } from "framer-motion";
import HeroSlider from "@/components/sections/HeroSlider";
import Categories from "@/components/sections/Categories";
import FeaturedProducts from "@/components/sections/FeaturedProducts";
import Newsletter from "@/components/sections/Newsletter";
import { staggerContainer } from "@/lib/animations";
import { FeaturedSection } from "@/components/sections/FeaturedSection";
import { MessageCircleCode } from "lucide-react";

export default function Home() {
  return (
    <>
      <motion.main
        variants={staggerContainer}
        initial="hidden"
        animate="show"
        className="min-h-screen"
      >
        <HeroSlider />
        <FeaturedSection />
        <Categories />
        <FeaturedProducts />
        {/* <NewArrivals /> */}
        {/* <Brands /> */}
        <Newsletter />
      </motion.main>

      {/* Fixed Message Button */}
       {/* Fixed Message Button with Hover Text */}
       <div className="fixed bottom-6 left-6 group">
  {/* Tooltip */}
  <span className="absolute left-12 w-28 hidden group-hover:flex bg-gray-800 text-white text-sm px-3 py-2 rounded-md shadow-lg">
    Contact Us
  </span>

  {/* Button */}
  <a
    href="https://www.messenger.com/t/489636774423136/"
    target="_blank"
    rel="noopener noreferrer"
    className="block"
  >
    <button
      className="bg-blue-600 w-10 h-10 flex items-center justify-center text-white p-2 rounded-full shadow-lg hover:bg-blue-700 transition"
    >
      <MessageCircleCode size={20} />
    </button>
  </a>
</div>

    </>
  );
}
