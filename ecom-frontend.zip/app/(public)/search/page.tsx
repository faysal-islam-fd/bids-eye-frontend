"use client";

import { motion } from "framer-motion";
import { ShopFilters } from "@/components/shop/shop-filters";
import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import productApiSlice from "@/redux/api/productsApiSlice";
import { useDispatch } from "react-redux";
import { IProduct } from "@/types";
import { ProductCardBase } from "@/components/product/ProductCard";
import { ProductGrid } from "@/components/shop/product-grid";
export default function CategoryPage() {
  const searchParam = useSearchParams();

  const q = searchParam.get("q");
  const [qStr, setQStr] = useState("");
  const dispatch = useDispatch();
  const [result, setResults] = useState(0);
  const [products, setProducts] = useState<IProduct[]>([]);
  const { data, isSuccess, refetch, isLoading } =
    productApiSlice.useSearchProductsQuery(qStr, {
      skip: !qStr,
    });

  useEffect(() => {
    const getQueryString = () => {
      const queryString = window.location.href.split("?")[1];
      return queryString ? `?${queryString}` : "";
    };

    const qString = getQueryString();
    setQStr(qString);
  }, [q]);

  useEffect(() => {
    if (qStr) {
      // dispatch(productApiSlice.util.invalidateTags(["Search"]));
      refetch();
      console.log("refetching");
    }
  }, [qStr]);

  useEffect(() => {
    console.log(data);
    if (data?.products) {
      setProducts(data?.products);
    }
    if (data?.count) {
      setResults(data?.count);
    }
  }, [isSuccess, data]);
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen bg-background"
    >
      <div className="container mx-auto px-4 py-8">
        {isSuccess && products.length > 0 && (
          <h1 className="text-3xl font-bold mb-8">{result} Collection</h1>
        )}
        <div className="flex flex-col lg:flex-row gap-8">
          <ShopFilters setQStr={setQStr} />
          {isLoading ? (
            "Loading..."
          ) : (
            <>
              {products?.length > 0 ? (
                <motion.div
                  initial="hidden"
                  animate="show"
                  className="flex-1 grid grid-cols-1 h-auto md:grid-cols-2 lg:grid-cols-3 gap-6"
                >
                  {products &&
                    products.map((product, index) => (
                      <ProductCardBase product={product} index={index} />
                    ))}
                </motion.div>
              ) : (
                <div className="flex justify-center">No products</div>
              )}
            </>
          )}
        </div>
      </div>
    </motion.div>
  );
}
