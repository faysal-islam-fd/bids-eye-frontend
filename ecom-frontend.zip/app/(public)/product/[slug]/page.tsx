"use client";
import { product } from "@/app/data/product";
import { relatedProducts } from "@/app/data/relatedProducts";
import ProductGallery from "@/components/product/ProductGallery";
import ProductInfo from "@/components/product/ProductInfo";
import RelatedProducts from "@/components/product/RelatedProducts";
import ProductDetailSkeleton from "@/components/skeleton/ProductDetailSkeleton";
import productApiSlice from "@/redux/api/productsApiSlice";
import { IProduct, IProductImage } from "@/types";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";

export default function ProductDetailsPage() {
  const { slug } = useParams();

  const { data, isSuccess, isLoading, isError } =
    productApiSlice.useGetProductDetailsQuery(slug, {
      skip: !slug,
    });
  const [product, setProduct] = useState<IProduct | null>(null);
  useEffect(() => {
    if (isSuccess) {
      if (data?.product) {
        setProduct(data?.product);
      }
    }
  }, [slug, data, isSuccess]);

  const newImages: IProductImage[] = [
    { id: 0, image: product?.image ?? "", product_id: product?.id ?? 0 },
    ...(product?.product_images ?? []),
  ];

  if (isLoading) {
    return <ProductDetailSkeleton />;
  }
  if (isError) {
    return <>Product not found</>;
  }

  return (
    <>
      <main className="min-h-screen bg-gradient-to-b from-gray-50 to-white dark:from-gray-900 dark:to-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16">
            <ProductGallery product_images={(product && newImages) ?? []} />
            {product && <ProductInfo product={product} />}
          </div>
        </div>
        <RelatedProducts />
      </main>
    </>
  );
}
