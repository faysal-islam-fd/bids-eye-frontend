/** @type {import('next').NextConfig} */
const nextConfig = {

  images: {
    domains: ["api.birdseyefashion.com"], // অনুমোদিত ডোমেইনের তালিকা
  },
};

module.exports = nextConfig;
